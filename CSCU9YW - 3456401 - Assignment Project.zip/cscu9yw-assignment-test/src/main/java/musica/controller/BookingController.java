package musica.controller;

import musica.model.*;
import musica.service.BookingService;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.RepresentationModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.time.DayOfWeek;
import java.util.List;
import java.util.Map;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;


@RestController
@CrossOrigin
public class BookingController {

    private final BookingService service;
    private static final String PREFIX_BEARER = "Bearer ";
    private static final Map<String, String> TUTOR_API_KEYS = Map.of(
            "stephen", "1",
            "maria", "2",
            "doug", "3");

    public BookingController(BookingService service) {
        this.service = service;
    }

    @GetMapping("/school")
    public ResponseEntity<RepresentationModel<?>> getRoot() {
        RepresentationModel<?> root = new RepresentationModel<>();
        root.add(linkTo(methodOn(BookingController.class).getRoot()).withSelfRel());
        root.add(linkTo(methodOn(BookingController.class).getTutors()).withRel("tutors"));
        root.add(Link.of(linkTo(BookingController.class).slash("booking").toString() + "{?matric}", "booking"));
        return new ResponseEntity<>(root, HttpStatus.OK);
    }

    @GetMapping("/tutor")
    public ResponseEntity<CollectionModel<EntityModel<Tutor>>> getTutors() {
        List<EntityModel<Tutor>> models = service.getTutors().stream().map(this::toTutorModel).toList();
        CollectionModel<EntityModel<Tutor>> collection = CollectionModel.of(models, linkTo(methodOn(BookingController.class).getTutors()).withSelfRel());
        return new ResponseEntity<>(collection, HttpStatus.OK);
    }

    @GetMapping("/tutor/{tutorId}")
    public ResponseEntity<EntityModel<Tutor>> getTutor(@PathVariable String tutorId) {
        return new ResponseEntity<>(toTutorModel(findTutor(tutorId)), HttpStatus.OK);
    }

    @GetMapping("/tutor/{tutorId}/slots")
    public ResponseEntity<RepresentationModel<?>> getWeek(@PathVariable String tutorId) {
        findTutor(tutorId);
        RepresentationModel<?> week = new RepresentationModel<>();
        week.add(linkTo(methodOn(BookingController.class).getWeek(tutorId)).withSelfRel());
        for (DayOfWeek day : service.getDaysOpen()) {
            String dayName = day.name().toLowerCase();
            week.add(linkTo(methodOn(BookingController.class).getSlots(dayName, tutorId)).withRel(dayName));
        }
        return new ResponseEntity<>(week, HttpStatus.OK);
    }

    @GetMapping("/tutor/{tutorId}/slots/{day}")
    public ResponseEntity<CollectionModel<Slot>> getSlots(@PathVariable String day, @PathVariable String tutorId) {
        Tutor tutor = findTutor(tutorId);
        List<Slot> slots = service.getAvailSlots(parseDayOpen(day), tutor.id());
        CollectionModel<Slot> model = CollectionModel.of(slots,
                linkTo(methodOn(BookingController.class).getSlots(day, tutorId)).withSelfRel(),
                linkTo(methodOn(BookingController.class).getWeek(tutorId)).withRel("slots"));
        return new ResponseEntity<>(model, HttpStatus.OK);
    }

    @PostMapping("/booking")
    public ResponseEntity<EntityModel<Booking>> bookLesson(@RequestBody Booking request) {
        Booking booked = service.bookLesson(request);
        URI location = linkTo(methodOn(BookingController.class).getBooking(booked.id())).toUri();
        return ResponseEntity.created(location).body(toModel(booked));
    }

    @GetMapping("/booking/{id}")
    public ResponseEntity<EntityModel<Booking>> getBooking(@PathVariable int id) {
        Booking booking = service.getLesson(id);
        if (booking == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(toModel(booking), HttpStatus.OK);
    }

    @GetMapping("/booking")
    public ResponseEntity<CollectionModel<EntityModel<Booking>>> getBookings(@RequestParam int matric) {
        List<EntityModel<Booking>> models = service.getBookingsPupil(matric).stream().map(this::toModel).toList();
        CollectionModel<EntityModel<Booking>> collection = CollectionModel.of(models,
                linkTo(methodOn(BookingController.class).getBookings(matric)).withSelfRel(),
                linkTo(methodOn(BookingController.class).getTutors()).withRel("tutors"));
        return new ResponseEntity<>(collection, HttpStatus.OK);
    }
    @DeleteMapping("/booking/{id}")
    public ResponseEntity<Void> cancelBooking(@PathVariable int id, @RequestParam int matric) {
        service.cancelBooking(id, matric);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/schedule/{tutorId}")
    public ResponseEntity<RepresentationModel<?>> getSchedule(@PathVariable String tutorId, @RequestHeader(value = "Authorization", required = false)
                                                              String auth) {
        checkTutorKey(auth, tutorId);
        findTutor(tutorId);
        RepresentationModel<?> schedule = new RepresentationModel<>();
        schedule.add(linkTo(methodOn(BookingController.class).getSchedule(tutorId, null)).withSelfRel());
        for (DayOfWeek day : service.getDaysOpen()) {
            String dayName = day.name().toLowerCase();
            schedule.add(linkTo(methodOn(BookingController.class).getCurrentSchedule(dayName, tutorId, null)).withRel(dayName));
        }
        return new ResponseEntity<>(schedule, HttpStatus.OK);
    }

    @GetMapping("/schedule/{tutorId}/{day}")
    public ResponseEntity<CollectionModel<EntityModel<Booking>>> getCurrentSchedule(@PathVariable String day, @PathVariable String tutorId,
                                                                                    @RequestHeader(value = "Authorization", required = false)
                                                                                    String auth) {
        checkTutorKey(auth, tutorId);
        findTutor(tutorId);
        List<EntityModel<Booking>> models = service.getCurrentBookings(parseDayOpen(day), tutorId).stream().map(this::toModel).toList();
        CollectionModel<EntityModel<Booking>> collection = CollectionModel.of(models, linkTo(methodOn(BookingController.class)
                .getCurrentSchedule(day, tutorId, null)).withSelfRel(), linkTo(methodOn(BookingController.class).getSchedule(tutorId, null)).withRel("schedule"));
        return new ResponseEntity<>(collection, HttpStatus.OK);

    }

    private EntityModel<Booking> toModel(Booking booking) {
        return EntityModel.of(booking, linkTo(methodOn(BookingController.class).getBooking(booking.id())).withSelfRel(),
                                       linkTo(methodOn(BookingController.class).getTutor(booking.tutor())).withRel("tutor"));

    }

    private EntityModel<Tutor> toTutorModel(Tutor tutor) {
        return EntityModel.of(tutor, linkTo(methodOn(BookingController.class).getTutor(tutor.id())).withSelfRel(),
                                     linkTo(methodOn(BookingController.class).getWeek(tutor.id())).withRel("slots"),
                                     linkTo(methodOn(BookingController.class).getSchedule(tutor.id(), null)).withRel("schedule"));
    }

    private void checkTutorKey(String auth, String tutorId) {
        if (auth == null || !auth.startsWith(PREFIX_BEARER)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "API Key required.");
        }
        String key = auth.substring(PREFIX_BEARER.length());
        if (!TUTOR_API_KEYS.containsValue(key)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid API Key.");
        }
        if (!key.equals(TUTOR_API_KEYS.get(tutorId))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Inputted API Key does not match Tutor.");
        }
    }

    private Tutor findTutor(String tutorId) {
        Tutor tutor = service.getTutor(tutorId);
        if (tutor == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        return tutor;
    }

    private DayOfWeek parseDayOpen(String day) {
        DayOfWeek parsed;
        try {
            parsed = DayOfWeek.valueOf(day.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        if (!service.getDaysOpen().contains(parsed)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        return parsed;
    }
}
