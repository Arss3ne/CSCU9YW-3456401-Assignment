package musica.model;

import java.time.DayOfWeek;
import java.time.LocalTime;

public record Booking(Integer id, int matric, String name, String tutor, String instrument, DayOfWeek day, LocalTime start) {

    public Slot slot() {
        return new Slot(day, start);
    }
}
