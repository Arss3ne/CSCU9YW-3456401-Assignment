package musica.model;

import java.time.DayOfWeek;
import java.time.LocalTime;

public record Slot(DayOfWeek day, LocalTime start) {
}
