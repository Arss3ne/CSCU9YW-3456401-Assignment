package musica.model;

import java.util.Map;

public record Tutor(String id, String name, Map<String, LevelRange> instruments) {

    public record LevelRange(int minGrade, int maxGrade) {
        public boolean includes(int grade) {
            return grade >= minGrade && grade <= maxGrade;
        }
    }

    public boolean teaches(String instrument, int grade) {
        LevelRange range = instruments.get(instrument);
        return range != null && range.includes(grade);
    }
}
