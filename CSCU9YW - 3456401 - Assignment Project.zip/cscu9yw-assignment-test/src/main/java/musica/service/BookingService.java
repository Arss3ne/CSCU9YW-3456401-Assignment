package musica.service;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.*;

import musica.model.*;
import musica.service.PupilTracker.PupilResponse.Pupil;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class BookingService {

    private static final List<DayOfWeek> DAYS_OPEN = List.of(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY);
    private static final LocalTime WEEKDAY_WHEN_OPEN = LocalTime.of(16, 0);
    private static final LocalTime SATURDAY_WHEN_OPEN = LocalTime.of(9, 0);
    private static final LocalTime CLOSING = LocalTime.of(20, 0);
    private static final int LESSON_DURATION_MINUTES = 30;

    private static final int PUPIL_YOUNG_AGE = 16;
    private static final LocalTime CUTOFF_TIME_YOUNG_PUPIL = LocalTime.of(18, 0);

    private final Map<String, Tutor> tutorList = new LinkedHashMap<>();
    private final PupilTracker pupilTracker;
    private final Map<Integer, Booking> bookings = new LinkedHashMap<>();
    private int nextBookingId = 1;

    public BookingService(PupilTracker pupilTracker) {
        this.pupilTracker = pupilTracker;
        addTutor(new Tutor("stephen", "Stephen Reinhardt", Map.of(
                "piano", new Tutor.LevelRange(3, 7),
                "guitar", new Tutor.LevelRange(1, 8),
                "oboe", new Tutor.LevelRange(1, 8)
        )));
        addTutor(new Tutor("maria", "Maria Clocktower", Map.of(
                "violin", new Tutor.LevelRange(3, 7),
                "flute", new Tutor.LevelRange(1, 8),
                "piano", new Tutor.LevelRange(1, 4)
        )));
        addTutor(new Tutor("doug", "DougDoug Doug", Map.of(
                "guitar", new Tutor.LevelRange(4, 8),
                "drums", new Tutor.LevelRange(1, 8),
                "clarinet", new Tutor.LevelRange(1, 8)
        )));
    }

    public void addTutor(Tutor tutor) {
        tutorList.put(tutor.id(), tutor);
    }

    public List<Tutor> getTutors() {
        return new ArrayList<>(tutorList.values());
    }

    public Tutor getTutor(String id) {
        return tutorList.get(id);
    }

    public List<DayOfWeek> getDaysOpen() {
        return DAYS_OPEN;
    }

    public synchronized List<Slot> getAvailSlots(DayOfWeek day, String tutorId) {
        List<Slot> available = new ArrayList<>();
        for (Slot slot : allSlots(day)) {
            if (!isBooked(slot, tutorId)) {
                available.add(slot);
            }
        }
        return available;
    }

    private List<Slot> allSlots(DayOfWeek day) {
        List<Slot> slots = new ArrayList<>();
        if (!DAYS_OPEN.contains(day)) {
            return slots;
        }
        LocalTime open = day == DayOfWeek.SATURDAY ? SATURDAY_WHEN_OPEN : WEEKDAY_WHEN_OPEN;
        for (LocalTime start = open; start.isBefore(CLOSING); start = start.plusMinutes(LESSON_DURATION_MINUTES)) {
            slots.add(new Slot(day, start));
        }
        return slots;
    }

    private boolean isBooked(Slot slot, String tutorId) {
        for (Booking lesson : bookings.values()) {
            if (lesson.slot().equals(slot) && lesson.tutor().equals(tutorId)) {
                return true;
            }
        }
        return false;
    }

    public synchronized Booking getLesson(int id) {
        return bookings.get(id);
    }

    public synchronized List<Booking> getBookingsPupil(int matric) {
        List<Booking> found = new ArrayList<>();
        for (Booking booking : bookings.values()) {
            if (booking.matric() == matric) {
                found.add(booking);
            }
        }
        found.sort(Comparator.comparing(Booking::day).thenComparing(Booking::start));
        return found;
    }

    public synchronized List<Booking> getCurrentBookings(DayOfWeek day, String tutorId) {
        List<Booking> found = new ArrayList<>();
        for (Booking booking : bookings.values()) {
            if (booking.tutor().equals(tutorId) && booking.day() == day) {
                found.add(booking);
            }
        }
        found.sort(Comparator.comparing(Booking::start));
        return found;
    }

    public synchronized void cancelBooking(int id, int matric) {
        Booking booking = bookings.get(id);
        if (booking == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        if (booking.matric() != matric) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Bookings can only be cancelled by the pupil.");
        }
        bookings.remove(id);
    }

    public synchronized Booking bookLesson(Booking request) {
        if (request.name() == null || request.tutor() == null || request.instrument() == null || request.day() == null || request.start() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "These fields are required: name, tutor, instrument, day and start.");
        }
        Tutor tutor = tutorList.get(request.tutor());
        if (tutor == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Tutor not found.");
        }
        Slot slot = request.slot();
        if (!allSlots(request.day()).contains(slot)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No lesson slots in this time.");
        }

        Pupil pupil = pupilTracker.findPupil(request.matric());
        if (pupil == null || pupil.name() == null || !pupil.name().equalsIgnoreCase(request.name().trim())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Matriculation number and name does not match any record.");
        }

        String instrument = request.instrument().toLowerCase();
        Pupil.Level level = pupil.instruments() == null ? null : pupil.instruments().get(instrument);
        if (level == null || level.grade() == null || !tutor.teaches(instrument, level.grade())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Pupil's current grade does not meet tutor requirement.");
        }

        boolean isYoung = pupil.age() != null && pupil.age() < PUPIL_YOUNG_AGE;

        if (isYoung && !request.start().isBefore(CUTOFF_TIME_YOUNG_PUPIL)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Cannot book lessons starting at or after 6pm.");
        }

        if (isBooked(slot, tutor.id())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Current slot is already booked.");
        }
        for (Booking existing : bookings.values()) {
            if (existing.matric() == request.matric() && existing.day() == request.day()) {
                throw new ResponseStatusException(HttpStatus.CONFLICT, "Pupil already has a lesson in this day.");
            }
        }

        Booking booked = new Booking(nextBookingId++, request.matric(), pupil.name(), tutor.id(), instrument, request.day(), request.start());
        bookings.put(booked.id(), booked);
        return booked;
    }


}
