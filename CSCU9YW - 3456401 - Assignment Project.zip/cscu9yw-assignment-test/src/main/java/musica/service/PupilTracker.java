package musica.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

@Component
public class PupilTracker {
    private static final String URL_TRACKER = "https://pmaier.eu.pythonanywhere.com/plt";

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record PupilResponse(Pupil pupil) {
        @JsonIgnoreProperties(ignoreUnknown = true)
        public record Pupil(String name, Integer age, Map<String, Level> instruments) {
            @JsonIgnoreProperties(ignoreUnknown = true)
            public record Level(Integer grade) {
            }
        }
    }
    private final RestClient restClient = RestClient.create(URL_TRACKER);
    public PupilResponse.Pupil findPupil(int matric) {
        try {
            PupilResponse response = restClient.get()
                    .uri("/pupil/{matric}", matric)
                    .retrieve()
                    .body(PupilResponse.class);
            return response == null ? null : response.pupil();
        } catch (HttpClientErrorException.NotFound e) {
            return null;
        } catch (RestClientException e) {
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY,
                    "pupil level tracker unavailable");
        }
    }
}
